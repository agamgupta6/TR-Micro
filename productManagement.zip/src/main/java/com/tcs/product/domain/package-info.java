/**
 * JPA domain objects.
 */
package com.tcs.product.domain;
