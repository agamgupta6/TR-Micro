/**
 * Spring Data JPA repositories.
 */
package com.tcs.product.repository;
