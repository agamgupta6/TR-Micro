/**
 * Spring Data Elasticsearch repositories.
 */
package com.tcs.product.repository.search;
