/**
 * Service layer beans.
 */
package com.tcs.product.service;
